/**
 * 
 */
/**
 * 
 */
module TeacherSeeker {
	requires java.desktop;
	requires gs.core;
}