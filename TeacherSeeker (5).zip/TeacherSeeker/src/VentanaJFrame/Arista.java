package VentanaJFrame;

public class Arista {

	int valor; // Calificacion
	String nombre_profesor;

	// Constructor
	public Arista(int valor, String nombre_profesor) {
		this.valor = valor;
		this.nombre_profesor = nombre_profesor;
	}

	
	public Arista SumarPeso() {
		valor++;
		return new Arista(valor, nombre_profesor);
	}

}
