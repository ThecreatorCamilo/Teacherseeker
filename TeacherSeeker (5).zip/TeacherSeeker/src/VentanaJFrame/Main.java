package VentanaJFrame;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.SingleGraph;

public class Main {
    public static void main(String[] args) {

    	MiVentana miVentana = new MiVentana();
}
    }
