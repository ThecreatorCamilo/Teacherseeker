package VentanaJFrame;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import org.graphstream.graph.*;
import org.graphstream.graph.implementations.*;

public class MiVentana extends JFrame {
	// Pestanas
	public JTabbedPane pestanas = new JTabbedPane();
	public JPanel PestanaCrearGrafo = new JPanel();
	public JPanel PestanaVotaciones = new JPanel();
	public static Profesores ClaseProfesores = new Profesores();
	public static Graph grafo = new MultiGraph("Grafo");
	// Componentes Pestana I
	public JComboBox<String> listaSemestres;
	public JComboBox<String> MateriasPorSemestre;
	public JLabel texto1 = new JLabel();
	public JButton botonAnadir = new JButton();
	public JButton botonEliminar = new JButton();
	public JButton botonConfirmar = new JButton();
	public JLabel texto2 = new JLabel();
	// public ArrayList<String> listaActualizadora = new ArrayList<String>();
	public DefaultListModel<String> lista = new DefaultListModel();
	public JList<String> listaMaterias = new JList(lista);
	public JScrollPane scrolleador = new JScrollPane(listaMaterias);
	public Grafo_Matriz_Adyacencia grafoNuevo;
	public String[] Semestres = { "Semestre 1", "Semestre 2", "Semestre 3", "Semestre 4", "Semestre 5", "Semestre 6",
			"Semestre 7", "Semestre 8", "Semestre 9", "Semestre 10" };
	public String[][] Materias = {
			{ "Calculo_I", "Fundamentos_de_Programacion", "Cultura_Fisica", "Algebra_Lineal_I", "Taller_de_Lenguaje",
					"Quimica_Basica" },
			{ "Calculo_II", "Etica_Ciudadana", "Fisica_I", "Programacion_Orientada_a_Objetos",
					"Biologia_para_Ingenieros", "Ingles_I" },
			{ "Calculo_III", "Fisica_II", "Matematicas_Discretas", "Estructuras_de_Datos_y_Analisis_de_Algoritmos",
					"Ingles_II" },
			{ "Ecuaciones_Diferenciales", "Fisica_III", "Electricidad_y_Electronica", "Automatas_y_Lenguajes_Formales",
					"Base_de_Datos_I" },
			{ "Base_de_Datos_II", "Sistemas_Digitales", "Analisis_Numerico_I", "Pensamiento_Sistemico_y_Organizacional",
					"Direccion_Empresarial_I" },
			{ "Estadistica_I", "Redes_de_Computadores_I", "Arquitectura_de_Computadores", "Programacion_en_la_Web",
					"Sistemas_de_Informacion" },
			{ "Estadistica_II", "Ingenieria_del_Software_I", "Redes_de_Computadores_II", "Inteligencia_Artificial_I" },
			{ "Sistemas_Operacionales", "Ingenieria_de_Software_II", "Simulacion_Digital" },
			{ "Trabajo_de_Grado_I", "Ingenieria_Economica" }, { "Trabajo_de_Grado_II", "Economia_Empresarial" } };

// Componentes Pestana 2
	public JButton botonVotar = new JButton();
	public JComboBox<String> listaSemestres2;
	public JComboBox<String> MateriasPorSemestre2;
	public JComboBox<String> Profesores = new JComboBox<String>();
	public String styleSheet =
            "edge {" +
            "   shape: blob;" +
            "   size: 3px;" +
            "   arrow-shape: arrow;" +
            "}";

	public MiVentana() {
		configurarVentana(); // Configurar la ventana principal
		inicializarComponentes(); // Inicializar los componentes de la interfaz
		agregarEventos(); // Configurar los eventos
		setVisible(true); // Mostrar la ventana
	}

	// Método para configurar la ventana
	private void configurarVentana() {
		setTitle("TeacherSeeker");
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		getContentPane().setBackground(Color.WHITE);
		pestanas = new JTabbedPane();
		pestanas.setBounds(10, 10, 460, 420);
		pestanas.setBackground(Color.WHITE);
		add(pestanas);
	}

	public void inicializarComponentes() {
		// Crear los paneles para las dos pestañas
		PestanaCrearGrafo = PestanaCrearGrafo();
		PestanaVotaciones = PestanaVotaciones();

		// Agregar las pestañas al JTabbedPane
		pestanas.addTab("Grafo", PestanaCrearGrafo);
		pestanas.addTab("Votaciones", PestanaVotaciones);
	}

	// Método para inicializar los componentes
	public JPanel PestanaCrearGrafo() {
		JPanel panelCrearGrafo = new JPanel();
		panelCrearGrafo.setBackground(Color.WHITE);
		panelCrearGrafo.setLayout(null); // Establecer el diseño para este panel

		// Listas
		listaSemestres = new JComboBox<>(Semestres);
		MateriasPorSemestre = new JComboBox<>();

		listaSemestres.setBounds(50, 60, 150, 30);
		listaSemestres.setBackground(Color.WHITE);
		MateriasPorSemestre.setBounds(220, 60, 210, 30);
		MateriasPorSemestre.setBackground(Color.WHITE);

		// Texto Guia
		texto1.setText("Por favor selecciona las asignaturas que matriculaste este semestre");
		texto1.setBounds(50, 15, 400, 30);

		// Texto 2
		texto2.setText("Las materias seleccionadas son:");
		texto2.setBounds(50, 140, 200, 30);

		// Boton Anadir
		botonAnadir.setText("Añadir asignatura");
		botonAnadir.setBounds(170, 100, 180, 30);
		botonAnadir.setBackground(Color.WHITE);

		// Boton Eliminar
		botonEliminar.setText("Eliminar");
		botonEliminar.setBounds(100, 330, 120, 30);
		botonEliminar.setBackground(Color.WHITE);

		// Boton Confirmar
		botonConfirmar.setText("Confirmar");
		botonConfirmar.setBounds(240, 330, 120, 30);
		botonConfirmar.setBackground(Color.WHITE);

		// Lista
		scrolleador.setBounds(150, 190, 220, 100);

		// Inicializar la segunda lista con las materias del primer semestre
		actualizarMaterias(0, MateriasPorSemestre);

		///////////////////////////////////////////// ANADIR COMPONENTES AL PANEL

		panelCrearGrafo.add(listaSemestres); // anadir lista de semestres
		panelCrearGrafo.add(MateriasPorSemestre); // anadir lista de asignaturas
		panelCrearGrafo.add(texto1); // anadir texto guia
		panelCrearGrafo.add(texto2);
		panelCrearGrafo.add(botonAnadir); // anadir boton Anadir
		panelCrearGrafo.add(scrolleador); // anadir lista de materias
		panelCrearGrafo.add(botonEliminar);
		panelCrearGrafo.add(botonConfirmar);

		return panelCrearGrafo; // Devolver el panel completo
	}

	// Método para agregar los listeners a los objetos de la ventana
	public void agregarEventos() {
		listaSemestres.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int indiceSeleccionado = listaSemestres.getSelectedIndex();
				actualizarMaterias(indiceSeleccionado, MateriasPorSemestre);
			}
		});

		listaSemestres2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int indiceSeleccionado = listaSemestres2.getSelectedIndex();
				actualizarMaterias(indiceSeleccionado, MateriasPorSemestre2);
			}
		});

		botonAnadir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String itemSeleccionado = (String) MateriasPorSemestre.getSelectedItem();

				// Verificar si el elemento ya está en la lista
				boolean existe = false;
				for (int i = 0; i < lista.getSize(); i++) {
					if (lista.getElementAt(i).equals(itemSeleccionado)) {
						existe = true;
						break;
					}
				}

				// Si no existe, agregarlo a la lista
				if (!existe) {
					lista.addElement(itemSeleccionado);
				} else {
					JOptionPane.showMessageDialog(null, "Esta materia ya ha sido agregada.", "Advertencia",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		});

		botonEliminar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Obtener el índice del elemento seleccionado
				int indiceSeleccionado = listaMaterias.getSelectedIndex();

				// Verificar si hay un elemento seleccionado
				if (indiceSeleccionado != -1) {
					// Eliminar el elemento del modelo
					lista.remove(indiceSeleccionado);
				} else {
					// Mostrar un mensaje de advertencia si no hay selección
					JOptionPane.showMessageDialog(null, "Por favor selecciona una materia para eliminar.",
							"Advertencia", JOptionPane.WARNING_MESSAGE);
				}
			}
		});

		botonConfirmar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				grafoNuevo = new Grafo_Matriz_Adyacencia(lista.size() + 1);
				
				//agregar nodos
				for (int i = 0; i < lista.size(); i++) {
					String nombreAsignatura = lista.getElementAt(i);
					grafoNuevo.agregarNombreNodo(i, nombreAsignatura);
					grafo.addNode(nombreAsignatura);
					grafo.getNode(i).addAttribute("ui.style", "size: 20px; fill-color: green; text-size: 14px;");
					grafo.getNode(i).addAttribute("ui.label", nombreAsignatura);
					
				}
				grafoNuevo.agregarNombreNodo(lista.size(), "Final");
				grafo.addNode("Final");
				grafo.getNode(lista.size()).addAttribute("ui.label", "Final");
				grafo.getNode(lista.size()).addAttribute("ui.style", "size: 20px; fill-color: green; text-size: 14px;");
				//Agregar Aristas
				for (int i = 0; i < (lista.size()); i++) {
					String nombreAsignatura = lista.getElementAt(i);
					ArrayList<Arista> profesoresAsignatura = ClaseProfesores.getHashMapProfesores().get(nombreAsignatura);
					for (int n = 0; n < profesoresAsignatura.size(); n++) {
						String profesor = profesoresAsignatura.get(n).nombre_profesor; //Metemos todo lo relacionado con un profesor a una misma variable
						int valor = profesoresAsignatura.get(n).valor; //Metemos el valor relacionado al profesor a una variable valor
						String idArista = "Arista" + i + "-" + (i + 1) + "-" + profesor; //Le pone un identificador a la arista 
						if(grafo.getEdge(idArista)==null) {
						grafoNuevo.agregarArista(i, i + 1, profesor, valor); //agregamos la arista al grafo
						
						grafo.addEdge(idArista, i, i + 1); //identificador de la arista, nodo origen a nodo destino
						
						grafo.setAttribute("ui.stylesheet", styleSheet);
						
						
						}
							}
				}
			//	grafoNuevo.imprimirMatriz();
				grafoNuevo.camino();
				grafo.display();
				
			}
		});

		botonVotar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String NombreAsignatura = (String) MateriasPorSemestre2.getSelectedItem();
				
				int index = Profesores.getSelectedIndex();
				ClaseProfesores.getHashMapProfesores().get(NombreAsignatura).get(index).SumarPeso();
				ClaseProfesores.ImprimirArray(ClaseProfesores.getHashMapProfesores().get(NombreAsignatura));
			}

		});
		MateriasPorSemestre2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ActualizarProfesoresVotaciones(Profesores);

			}
		});
	}

	// Método para actualizar las materias en función del semestre seleccionado
	public void actualizarMaterias(int indice, JComboBox<String> MateriasAagregar) {
		MateriasAagregar.removeAllItems();
		for (String materia : Materias[indice]) {
			MateriasAagregar.addItem(materia);
		}

	}

	// Método para inicializar PestanaVotaciones
	public JPanel PestanaVotaciones() {
		JPanel panelVotaciones = new JPanel();
		panelVotaciones.setBackground(Color.WHITE);

		// LISTAS
		listaSemestres2 = new JComboBox<String>(Semestres);
		listaSemestres2.setBounds(listaSemestres.getBounds());
		listaSemestres2.setBackground(Color.WHITE);
		MateriasPorSemestre2 = new JComboBox<String>();
		MateriasPorSemestre2.setBounds(MateriasPorSemestre.getBounds());
		MateriasPorSemestre2.setBackground(Color.WHITE);
		ActualizarProfesoresVotaciones(Profesores);
		Profesores.setBounds(150, 100, 150, 30);
		Profesores.setBackground(Color.WHITE);
		botonVotar.setBounds(160, 150, 100, 30);
		botonVotar.setText("Votar");
		botonVotar.setBackground(Color.WHITE);
		panelVotaciones.setLayout(null);
		JLabel textoVotaciones = new JLabel("Vota por un profesor si te gustó como llevó su asignatura");
		JLabel textoVotaciones2 = new JLabel("y se lo recomendarias a otro estudiante");
		textoVotaciones.setBounds(50, 5, 400, 30);
		textoVotaciones2.setBounds(60, 20, 300, 30);
		panelVotaciones.add(textoVotaciones);
		panelVotaciones.add(textoVotaciones2);
		actualizarMaterias(0, MateriasPorSemestre2);
		panelVotaciones.add(listaSemestres2); // anadir lista de semestres
		panelVotaciones.add(MateriasPorSemestre2); // anadir lista de asignaturas
		panelVotaciones.add(botonVotar);
		panelVotaciones.add(Profesores);

		return panelVotaciones;
	}

	public void ActualizarProfesoresVotaciones(JComboBox<String> Prof) {
		Prof.removeAllItems();
		String NombreMateriaSeleccionada;
		if (MateriasPorSemestre2.getSelectedItem() == null) {
			NombreMateriaSeleccionada = "Calculo_I";
		} else {
			NombreMateriaSeleccionada = (String) MateriasPorSemestre2.getSelectedItem();
		}
		ArrayList<Arista> ListaObtenida = ClaseProfesores.getHashMapProfesores().get(NombreMateriaSeleccionada);
		for (int i = 0; i < ListaObtenida.size(); i++) {
			String NombreCucho = ListaObtenida.get(i).nombre_profesor;
			Prof.addItem(NombreCucho);
		}
	}
}
