package VentanaJFrame;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class Grafo_Matriz_Adyacencia {
	public int V; // Número de nodos (materias)
	public int A; // Número de aristas (profesores)
	public String[] nombreNodos; // Arreglo para los nombres de las materias
	public ArrayList<Arista>[][] matrizAdyacencia; // Matriz de listas de aristas
	//public ArrayList<String> nombreAristas;

	// Constructor
	public Grafo_Matriz_Adyacencia(int nodos) {
		this.V = nodos;
		this.A = 0;
		this.nombreNodos = new String[nodos];
		this.matrizAdyacencia = new ArrayList[nodos][nodos];
		//this.nombreAristas = new ArrayList<String>();
		 for (int i = 0; i < nodos; i++) {
		        for (int j = 0; j < nodos; j++) {
		            matrizAdyacencia[i][j] = new ArrayList<>();
		        }
		    }
	
	}

	public void agregarNombreNodo(int nodo, String nombre) {
		if (nodo >= 0 && nodo < V) {
			nombreNodos[nodo] = nombre;

		}
	}

	public void agregarArista(int u, int v, String nombre_profesor, int valor) {

		matrizAdyacencia[u][v].add(new Arista(valor, nombre_profesor));	
		//nombreAristas.add(nombre_profesor);
		A++;
	}
/*
	public void imprimirMatriz() {

		for (int i = 0; i < V; i++) {
			System.out.println("Materia: " + nombreNodos[i] + " ->");
			for (int j = 0; j < V; j++) {
				if (!matrizAdyacencia[i][j].isEmpty()) {
					System.out.print(nombreNodos[j] + ": ");
					for (Arista arista : matrizAdyacencia[i][j]) {
						System.out.print(arista + " ");
					}
					System.out.println();
				}
			}
		}
	}
	*/
	
	public void camino() {
	    // Posición dentro del Array de profesores con mejor valoración
	    int K = 0;
	    StringBuilder impresion = new StringBuilder();
	    
	    // Se recorre todas las filas (materias)
	    for (int i = 0; i < V - 1; i++) {
	        int mayorPeso = 0;
	        // Se recorren todos los profesores de la materia i
	        for (int k = 0; k < matrizAdyacencia[i][i + 1].size(); k++) {
	            // Si su votación es mejor que la anterior, pasa a ser el mejor votado
	            if (matrizAdyacencia[i][i + 1].get(k).valor > mayorPeso) {
	                mayorPeso = matrizAdyacencia[i][i + 1].get(k).valor;
	                K = k;
	            }
	        }
	        // Agrega la información al StringBuilder
	        impresion.append("Materia: ")
	                 .append(nombreNodos[i])
	                 .append(" -> ")
	                 .append(matrizAdyacencia[i][i + 1].get(K).nombre_profesor)
	                 .append(" (")
	                 .append(matrizAdyacencia[i][i + 1].get(K).valor)
	                 .append(")\n");
	    }
	    
	    // Mostrar el mensaje en una ventana emergente
	    JOptionPane.showMessageDialog(null, impresion.toString(), "Camino Calculado", JOptionPane.INFORMATION_MESSAGE);
	}
}
