package VentanaJFrame;

import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JOptionPane;
public class Profesores {
	private ArrayList<Arista> Calculo_I = new ArrayList <> () ;//
	private ArrayList<Arista> Fundamentos_de_Programacion = new ArrayList<>();//
	private ArrayList<Arista> Quimica_Basica = new ArrayList<>();//
	private ArrayList<Arista> Algebra_Lineal_I = new ArrayList<>();//
	private ArrayList<Arista> Cultura_Fisica = new ArrayList<>();//
	private ArrayList<Arista> Taller_de_Lenguaje = new ArrayList<>();//
	private ArrayList<Arista> Calculo_II = new ArrayList<>();//
	private ArrayList<Arista> Etica_Ciudadana = new ArrayList<>();//
	private ArrayList<Arista> Fisica_I = new ArrayList<>();//
	private ArrayList<Arista> Programacion_Orientada_a_Objetos = new ArrayList<>();//
	private ArrayList<Arista> Biologia_para_Ingenieros = new ArrayList<>();//
	private ArrayList<Arista> Ingles_I = new ArrayList<>();//
	private ArrayList<Arista> Calculo_III = new ArrayList<>();//
	private ArrayList<Arista> Fisica_II = new ArrayList<>();//
	private ArrayList<Arista> Matematicas_Discretas = new ArrayList<>();//
	private ArrayList<Arista> Estructura_de_Datos = new ArrayList<>();//
	private ArrayList<Arista> Ingles_II = new ArrayList<>(); //
	private ArrayList<Arista> Ecuaciones_Diferenciales = new ArrayList<>();//
	private ArrayList<Arista> Fisica_III = new ArrayList<>();//
	private ArrayList<Arista> Electricidad_y_Electronica = new ArrayList<>();
	private ArrayList<Arista> Automatas_y_Lenguajes_Formales = new ArrayList<>();
	private ArrayList<Arista> Base_de_Datos_I = new ArrayList<>();
	private ArrayList<Arista> Base_de_Datos_II = new ArrayList<>();
	private ArrayList<Arista> Sistemas_Digitales = new ArrayList<>();
	private ArrayList<Arista> Analisis_Numerico_I = new ArrayList<>();
	private ArrayList<Arista> Pensamiento_Sistemico_y_Organizacional = new ArrayList<>();
	private ArrayList<Arista> Direccion_Empresarial_I = new ArrayList<>();
	private ArrayList<Arista> Estadistica_I = new ArrayList<>();
	private ArrayList<Arista> Redes_de_Computadores_I = new ArrayList<>();//
	private ArrayList<Arista> Arquitectura_de_Computadores = new ArrayList<>();
	private ArrayList<Arista> Programacion_en_la_Web = new ArrayList<>();
	private ArrayList<Arista> Sistemas_de_Informacion = new ArrayList<>();
	private ArrayList<Arista> Estadistica_II = new ArrayList<>();
	private ArrayList<Arista> Ingenieria_del_Software_I = new ArrayList<>();
	private ArrayList<Arista> Redes_de_Computadores_II = new ArrayList<>();
	private ArrayList<Arista> Inteligencia_Artificial_I = new ArrayList<>();
	private ArrayList<Arista> Sistemas_Operacionales = new ArrayList<>();
	private ArrayList<Arista> Ingenieria_del_Software_II = new ArrayList<>();
	private ArrayList<Arista> Simulacion_Digital = new ArrayList<>();
	private ArrayList <Arista> Ingenieria_Economica = new ArrayList<>();
	private ArrayList <Arista> Trabajo_de_Grado_I = new ArrayList<>();
	private ArrayList <Arista> Economia_Empresarial = new ArrayList<>();
	private ArrayList <Arista> Trabajo_de_Grado_II = new ArrayList<>();
	
	public Profesores() {
		ArraysProfesores();
		}
	
	public HashMap<String, ArrayList<Arista>> getHashMapProfesores(){
		HashMap<String, ArrayList<Arista>> asignaturasMap = new HashMap<>();
    	asignaturasMap.put("Calculo_I", getCalculoI());
    	asignaturasMap.put("Fundamentos_de_Programacion", getFundamentosDeProgramacion());
    	asignaturasMap.put("Quimica_Basica", getQuimicaBasica());
    	asignaturasMap.put("Algebra_Lineal_I", getAlgebraLinealI());
    	asignaturasMap.put("Cultura_Fisica", getCulturaFisica());
    	asignaturasMap.put("Taller_de_Lenguaje", getTallerDeLenguaje());
    	asignaturasMap.put("Calculo_II", getCalculoII());
    	asignaturasMap.put("Etica_Ciudadana", getEticaCiudadana());
    	asignaturasMap.put("Fisica_I", getFisicaI());
    	asignaturasMap.put("Programacion_Orientada_a_Objetos", getPOO());
    	asignaturasMap.put("Biologia_para_Ingenieros", getBiologiaParaIngenieros());
    	asignaturasMap.put("Ingles_I", getInglesI());
    	asignaturasMap.put("Calculo_III", getCalculoIII());
    	asignaturasMap.put("Fisica_II", getFisicaII());
    	asignaturasMap.put("Matematicas_Discretas", getMatematicasDiscretas());
    	asignaturasMap.put("Estructuras_de_Datos_y_Analisis_de_Algoritmos",getEstructuraDeDatos());
    	asignaturasMap.put("Ingles_II", getInglesII());
    	asignaturasMap.put("Ecuaciones_Diferenciales", getEcuacionesDiferenciales());
    	asignaturasMap.put("Fisica_III", getFisicaIII());
    	asignaturasMap.put("Electricidad_y_Electronica", getElectricidadyElectronica());
    	asignaturasMap.put("Automatas_y_Lenguajes_Formales", getAutomatasyLenguajesFormales());
    	asignaturasMap.put("Base_de_Datos_I", getBasedeDatosI());
    	asignaturasMap.put("Base_de_Datos_II", getBasedeDatosII());
    	asignaturasMap.put("Sistemas_Digitales", getSistemasDigitales());
    	asignaturasMap.put("Analisis_Numerico_I", getAnalisisNumericoI());
    	asignaturasMap.put("Pensamiento_Sistemico_y_Organizacional", getPensamientoSistemicoyOrganizacional());
    	asignaturasMap.put("Direccion_Empresarial_I", getDireccionEmpresarialI());
    	asignaturasMap.put("Estadistica_I", getEstadisticaI());
    	asignaturasMap.put("Redes_de_Computadores_I", getRedesDeComputadoresI());
    	asignaturasMap.put("Arquitectura_de_Computadores", getArquitecturaDeComputadores());
    	asignaturasMap.put("Programacion_en_la_Web", getProgramacionenlaWeb());
    	asignaturasMap.put("Sistemas_de_Informacion", getSistemasDeInformacion());
    	asignaturasMap.put("Estadistica_II", getEstadistica_II());
    	asignaturasMap.put("Ingenieria_del_Software_I", getIngenieriadelSoftwareI());
    	asignaturasMap.put("Redes_de_Computadores_II", getRedesdeComputadoresII());
    	asignaturasMap.put("Inteligencia_Artificial_I", getInteligenciaArtificialI());
    	asignaturasMap.put("Sistemas_Operacionales", getSistemasOperacionales());
    	asignaturasMap.put("Ingenieria_de_Software_II", getIngenieriadelSoftware_II());
    	asignaturasMap.put("Simulacion_Digital", getSimulacionDigital());
    	asignaturasMap.put("Ingenieria_Economica", getIngenieriaEconomica());
    	asignaturasMap.put("Trabajo_de_Grado_I", getTrabajodeGradoI());
    	asignaturasMap.put("Economia_Empresarial", getEconomiaEmpresarial());
    	asignaturasMap.put("Trabajo_de_Grado_II", getTrabajodeGradoII());
    	
    	return asignaturasMap;
	}
	public void ArraysProfesores() {
	 
	
     Calculo_I.add(new Arista(0, "YULIETH ALEXANDRA GUTIERREZ CARRILLO"));
     Calculo_I.add(new Arista(0,"LUIS ANTONIO ORTIZ"));
     Calculo_I.add(new Arista(0,"DANIEL MORENO CAICEDO"));
     Calculo_I.add(new Arista(0,"EDSON JAIR SUAREZ PORRAS"));
     Calculo_I.add(new Arista(0,"JUAN DAVID FRANCO SALAZAR"));

     
     Fundamentos_de_Programacion.add(new Arista(0,"LEONEL PARRA PINILLA"));
     Fundamentos_de_Programacion.add(new Arista(0,"ANDRES LEONARDO GONZALEZ GOMEZ"));
     Fundamentos_de_Programacion.add(new Arista(0,"ROSAURA GUTIERREZ ALMEYDA"));
     Fundamentos_de_Programacion.add(new Arista(0,"DUVAN YAHIR SANABRIA ECHEVERRY"));

     
     Quimica_Basica.add(new Arista(0,"FRANCI NATHALIE GOMEZ JAIMES"));
     Quimica_Basica.add(new Arista(0,"GERARDO BAUTISTA ARDILA"));
     Quimica_Basica.add(new Arista(0,"SANDRA MILENA CADENA CAMACHO"));
     Quimica_Basica.add(new Arista(0,"MARIA MERCEDES GONZALEZ BERNAL"));
     Quimica_Basica.add(new Arista(0,"SANDRA MILENA PINTO BOHORQUEZ"));

     
     Algebra_Lineal_I.add(new Arista(0,"EDWIN ANDRES AMAYA SANCHEZ"));
     Algebra_Lineal_I.add(new Arista(0,"LEIDY VANESA ESPITIA CRUZ"));
     Algebra_Lineal_I.add(new Arista(0,"NATALIA ISABEL PEREZ NIÑO"));
     Algebra_Lineal_I.add(new Arista(0,"ALEXANDER BETANCUR SANCHEZ"));
     Algebra_Lineal_I.add(new Arista(0,"JORGE ANDRES ROJAS GOMEZ"));

     
     Cultura_Fisica.add(new Arista(0,"MONICA SUAREZ LEÓN"));
     Cultura_Fisica.add(new Arista(0,"JAVIER GILMAR TOLOZA ARCINIEGAS"));
     Cultura_Fisica.add(new Arista(0,"RICARDO CASTELLANOS MARTINEZ"));
     Cultura_Fisica.add(new Arista(0,"JUAN SEBASTIÁN DEL VILLAR NIETO"));
     Cultura_Fisica.add(new Arista(0,"LIANELL JOVA ELEJALDE"));

     
     Taller_de_Lenguaje.add(new Arista(0,"LAURA CRISTINA BONILLA NEIRA"));
     Taller_de_Lenguaje.add(new Arista(0,"PAOLA ANDREA LOPEZ RINCON"));
     Taller_de_Lenguaje.add(new Arista(0,"JULIETH SANDRY MEZA ROMERO"));
     Taller_de_Lenguaje.add(new Arista(0,"ROSMAR GUERRERO TREJO"));
     Taller_de_Lenguaje.add(new Arista(0,"LEONOR AVILES ARENAS"));
 // SEGUNDO SEMESTRE
     
     Calculo_II.add(new Arista(0,"PEDRO NEL JAIMES JAIMES"));
     Calculo_II.add(new Arista(0,"YOANA ACEVEDO RICO"));
     Calculo_II.add(new Arista(0,"JUAN CARLOS LOPEZ RIOS"));
     Calculo_II.add(new Arista(0,"MARISEL ARDILA AMADOR"));
     Calculo_II.add(new Arista(0,"IVAN DARIO VEGA PACHECO"));

     
     Etica_Ciudadana.add(new Arista(0,"CARLOS ALBERTO VILLARREAL ANGULO"));
     Etica_Ciudadana.add(new Arista(0,"SINDY NORELLY ANAYA ACEVEDO"));
     Etica_Ciudadana.add(new Arista(0,"MANUEL EDUARDO MORENO GARCIA"));
     Etica_Ciudadana.add(new Arista(0,"LAURA MICHELLE MANTILLA ASCENCIO"));
     Etica_Ciudadana.add(new Arista(0,"JUAN CAMILO SARMIENTO LOBO"));

    
     Fisica_I.add(new Arista(0,"ADRIANA LUCIA GÉLVEZ CORTES"));
     Fisica_I.add(new Arista(0,"BRAYAN ALBERTO ARENAS BLANCO"));
     Fisica_I.add(new Arista(0,"RAFAEL CABANZO HERNANDEZ"));
     Fisica_I.add(new Arista(0,"KAROL VIANNEY SALAZAR ARIZA"));
     Fisica_I.add(new Arista(0,"HAROLD PAREDES GUTIERREZ"));

    
     Programacion_Orientada_a_Objetos.add(new Arista(0,"FERNANDO ANTONIO ROJAS MORALES"));
     Programacion_Orientada_a_Objetos.add(new Arista(0,"DUVAN YAHIR SANABRIA ECHEVERRY"));
     Programacion_Orientada_a_Objetos.add(new Arista(0,"DARIO ALEJANDRO RIAÑO VELANDIA"));

     
     Biologia_para_Ingenieros.add(new Arista(0,"NASSER GUERRERO BERMUDEZ"));
     Biologia_para_Ingenieros.add(new Arista(0,"JAIDER MUÑOZ GUERRERO"));
     Biologia_para_Ingenieros.add(new Arista(0,"FRANCISCO JOSE MARTINEZ PEREZ"));

     
     Ingles_I.add(new Arista(0,"LUIS FERNANDO ANAYA AGUIRRE"));
     Ingles_I.add(new Arista(0,"REYNA ROCIO ROJAS ESPARZA"));
     Ingles_I.add(new Arista(0,"CAROLINA GOMEZ MELENDEZ"));
     Ingles_I.add(new Arista(0,"GISELL PAOLA AREVALO GARCIA"));
     Ingles_I.add(new Arista(0,"LINA BETTY SAIZ"));
 //TERCER SEMESTRE
     
     Calculo_III.add(new Arista(0,"OSCAR LOZANO MANTILLA"));
     Calculo_III.add(new Arista(0,"ALEXANDER REATGIA VILLAMIZAR"));
     Calculo_III.add(new Arista(0,"GIOVANNI ERNESTO CALDERON SILVA"));
     Calculo_III.add(new Arista(0,"LUIS DAVID ORTIZ MARTINEZ"));
     Calculo_III.add(new Arista(0,"DUWAMG ALEXIS PRADA MARIN"));

     
     Fisica_II.add(new Arista(0,"ARTURO PLATA GOMEZ"));
     Fisica_II.add(new Arista(0,"LAURA LARA ORTIZ"));
     Fisica_II.add(new Arista(0,"WILLIAN GUTIERREZ NIÑO"));
     Fisica_II.add(new Arista(0,"ALEXANDRA PLATA PLANIDINA"));
     Fisica_II.add(new Arista(0,"HECTOR FROILAN HERNÁNDEZ GUERRA"));

     
     Matematicas_Discretas.add(new Arista(0,"CLAUDIA VICTORIA CORREA PUGLIESE"));
     Matematicas_Discretas.add(new Arista(0,"JONNATHAN ALFREDO RAMOS CHAUX"));

     
     Estructura_de_Datos.add(new Arista(0,"LAURA VIVIANA GALVIS CARREÑO"));
     Estructura_de_Datos.add(new Arista(0,"HOOVER FABIAN RUEDA CHACON"));

     
     Ingles_II.add(new Arista(0,"CARLOS JULIO SILVA BARON"));
     Ingles_II.add(new Arista(0,"CAROLINA GOMEZ MELENDEZ"));
     Ingles_II.add(new Arista(0,"MARIA CAMILA SERRANO GOMEZ"));
     Ingles_II.add(new Arista(0,"SIRLEY YULIANA MORA LERMA"));
     Ingles_II.add(new Arista(0,"NELSON EDUARDO DORADO LUJAN"));
 //CUARTO SEMESTRE
     
     Ecuaciones_Diferenciales.add(new Arista(0,"DORIS EVILA GONZALEZ ROJAS"));
     Ecuaciones_Diferenciales.add(new Arista(0,"ALVARO JAVIER ANDRADE DURAN"));
     Ecuaciones_Diferenciales.add(new Arista(0,"MAYRA ISABEL FERREIRA ORTIZ"));
     Ecuaciones_Diferenciales.add(new Arista(0,"LUIS DAVID ORTIZ MARTINEZ"));
     Ecuaciones_Diferenciales.add(new Arista(0,"CARLOS AUGUSTO DIAZ ROJAS"));

     
     Fisica_III.add(new Arista(0,"LUIS FRANCISCO GARCIA RUSSI"));
     Fisica_III.add(new Arista(0,"JADER ENRIQUE GONZALEZ CUJIA"));
     Fisica_III.add(new Arista(0,"FERNANDO DURAN FLOREZ"));
     Fisica_III.add(new Arista(0,"YEZID TORRES MORENO"));
     Fisica_III.add(new Arista(0,"ELBER RODRIGUEZ MORENO"));

     
     Electricidad_y_Electronica.add(new Arista(0,"JOSE GERALBERT RUBIANO"));
     Electricidad_y_Electronica.add(new Arista(0,"LUIS IGNACIO GONZALEZ RAMIREZ"));

     
     Automatas_y_Lenguajes_Formales.add(new Arista(0,"CLAUDIA VICTORIA CORREA PUGLIESE"));
     Automatas_y_Lenguajes_Formales.add(new Arista(0,"LUIS CARLOS GUAYACAN CHAPARRO"));

     
     Base_de_Datos_I.add(new Arista(0,"JUAN RAMON PERNALTE MALDONADO"));
     Base_de_Datos_I.add(new Arista(0,"JATHINSON MENESES MENDOZA"));
 //QUINTO SEMESTRE
     
     Base_de_Datos_II.add(new Arista(0,"JATHINSON MENESES MENDOZA"));
     Base_de_Datos_II.add(new Arista(0,"HENRY ANDRES JIMENEZ HERRERA"));

     
     Sistemas_Digitales.add(new Arista(0,"JOSE GERALBERT RUBIANO"));
     Sistemas_Digitales.add(new Arista(0,"JUAN RAMON PERNALTE MALDONADO"));

    
     Analisis_Numerico_I.add(new Arista(0,"JORGE LUIS BACCA QUINTERO"));
     Analisis_Numerico_I.add(new Arista(0,"HENRY ARGUELLO FUENTES"));

     
     Pensamiento_Sistemico_y_Organizacional.add(new Arista(0,"HUGO HERNANDO ANDRADE SOSA"));

     
     Direccion_Empresarial_I.add(new Arista(0,"ANGELICA MARIA DIAZ GOMEZ"));
     Direccion_Empresarial_I.add(new Arista(0,"JUAN FRANCISCO MARADEI GARCIA"));
     Direccion_Empresarial_I.add(new Arista(0,"HECTOR ARMANDO BARRERA CACERES"));
     Direccion_Empresarial_I.add(new Arista(0,"OSCAR ARMANDO VARGAS LOPEZ"));
     Direccion_Empresarial_I.add(new Arista(0,"YESID ALEXANDER OLAVE CACERES"));
 //SEXTO SEMESTRE
     
     Estadistica_I.add(new Arista(0,"HOOVER FABIAN RUEDA CHACON"));
     Estadistica_I.add(new Arista(0,"ELIANA MARTHA BONALDE MARCANO"));

     
     Redes_de_Computadores_I.add(new Arista(0,"JOHN WILLIAM VASQUEZ CAPACHO"));
     Redes_de_Computadores_I.add(new Arista(0,"PEDRO JAVIER TRUJILLO TARAZONA"));

     
     Arquitectura_de_Computadores.add(new Arista(0,"LUIS ALEJANDRO TORRES NINO"));
     Arquitectura_de_Computadores.add(new Arista(0,"JOSE GERALBERT RUBIANO"));
     Arquitectura_de_Computadores.add(new Arista(0,"PABLO JOSUE ROJAS YEPES"));

     
     Programacion_en_la_Web.add(new Arista(0,"MANUEL GUILLERMO FLOREZ BECERRA"));
     Programacion_en_la_Web.add(new Arista(0,"HENRY ANDRES JIMENEZ HERRERA"));
     Programacion_en_la_Web.add(new Arista(0,"DARIO ALEJANDRO RIANO VELANDIA"));

     
     Sistemas_de_Informacion.add(new Arista(0,"YESID ALEXANDER OLAVE CACERES"));
     Sistemas_de_Informacion.add(new Arista(0,"JUAN MANUEL DURAN MARIN"));
     Sistemas_de_Informacion.add(new Arista(0,"LAURA PATRICIA PINTO PRIETO"));
 //SEPTIMO SEMESTRE
     
     Estadistica_II.add(new Arista(0,"ANDRES LEONARDO GONZALEZ GOMEZ"));
     Estadistica_II.add(new Arista(0,"DAVID EDMUNDO ROMO BUCHELI"));
     Estadistica_II.add(new Arista(0,"CARLOS ALFONSO MANTILLA DUARTE"));

     
     Ingenieria_del_Software_I.add(new Arista(0,"GABRIEL RODRIGO PEDRAZA FERREIRA"));
     Ingenieria_del_Software_I.add(new Arista(0,"FERNANDO ANTONIO ROJAS MORALES"));
     Ingenieria_del_Software_I.add(new Arista(0,"DUVAN YAHIR SANABRIA ECHEVERRY"));
     Ingenieria_del_Software_I.add(new Arista(0,"EMILIO JUSTINIANO CARCAMO TROCONIS"));

     
     Redes_de_Computadores_II.add(new Arista(0,"GILBERTO JAVIER DIAZ TORO"));
     Redes_de_Computadores_II.add(new Arista(0,"JOHN WILLIAM VASQUEZ CAPACHO"));

     
     Inteligencia_Artificial_I.add(new Arista(0,"FABIO MARTINEZ CARRILLO"));
     Inteligencia_Artificial_I.add(new Arista(0,"GUSTAVO ADOLFO GARZON VILLAMIZAR"));
 //OCTAVO SEMESTRE
     
     Sistemas_Operacionales.add(new Arista(0,"MANUEL GUILLERMO FLOREZ BECERRA"));
     Sistemas_Operacionales.add(new Arista(0,"PABLO JOSUE ROJAS YEPES"));

     
     Ingenieria_del_Software_II.add(new Arista(0,"URBANO ELIECER GOMEZ PRADA"));
     Ingenieria_del_Software_II.add(new Arista(0,"JATHINSON MENESES MENDOZA"));

     
     Simulacion_Digital.add(new Arista(0,"ANDRES LEONARDO GONZALEZ GOMEZ"));
     Simulacion_Digital.add(new Arista(0,"DAVID EDMUNDO ROMO BUCHELI"));
 //NOVENO SEMESTRE
     
     Ingenieria_Economica.add(new Arista(0,"LAURA DANIELA GARCER CARREÑO"));
     Ingenieria_Economica.add(new Arista(0,"JOSE ALONSO CABALLERO MARQUEZ"));
     Ingenieria_Economica.add(new Arista(0,"SAIDA MIREYA GOMEZ ARCHILA"));
     Ingenieria_Economica.add(new Arista(0,"JOSE JOAQUIN ALZATE MARIN"));
     Ingenieria_Economica.add(new Arista(0,"JOSE LUIS GARCES BAUTISTA"));
     
     
     Trabajo_de_Grado_I.add(new Arista(0,"URBANO ELIECER GOMEZ PRADA"));
     Trabajo_de_Grado_I.add(new Arista(0,"USTAVO ADOLFO GARZON VILLAMIZAR"));
 
 //DECIMO SEMESTRE
     
     Economia_Empresarial.add(new Arista(0,"VICTOR JULIO DALLO HERNANDEZ"));
     Economia_Empresarial.add(new Arista(0,"CLAUDIA PATRICIA COTE DE SIERRA"));
     
     
     Trabajo_de_Grado_II.add(new Arista(0,"GILBERTO JAVIER DIAZ TORO"));
     Trabajo_de_Grado_II.add(new Arista(0,"DUVAN YAHIR SANABRIA ECHEVERRY"));
 }
	public ArrayList<Arista> getCalculoI() {
		return Calculo_I;
	}
	
	public ArrayList<Arista> getCalculoII(){
		return Calculo_II;
	}
	
	public ArrayList<Arista> getCalculoIII(){
		return Calculo_III;
	}
	
	public ArrayList<Arista> getEcuacionesDiferenciales(){
		return Ecuaciones_Diferenciales;
	}
	public ArrayList<Arista> getFundamentosDeProgramacion(){
		return Fundamentos_de_Programacion;
	}
	
	public ArrayList<Arista> getTallerDeLenguaje(){
		return Taller_de_Lenguaje;
	}
	
	public ArrayList<Arista> getQuimicaBasica(){
		return Quimica_Basica;
	}
	
	public ArrayList<Arista> getAlgebraLinealI(){
		return Algebra_Lineal_I;
	}
	
	public ArrayList<Arista> getCulturaFisica(){
		return Cultura_Fisica;
	}
	
	public ArrayList<Arista> getEticaCiudadana(){
		return Etica_Ciudadana;
	}
	
	public ArrayList<Arista> getPOO(){
		return Programacion_Orientada_a_Objetos;
	}
	
	public ArrayList<Arista> getFisicaI(){
		return Fisica_I;
	}
	
	public ArrayList<Arista> getFisicaII(){
		return Fisica_II;
	}
	
	public ArrayList<Arista> getFisicaIII(){
		return Fisica_III;
	}
	
	public ArrayList<Arista> getEstructuraDeDatos(){
		return Estructura_de_Datos;
	}
	
	public ArrayList<Arista> getInglesI(){
		return Ingles_I;
	}
	
	public ArrayList<Arista> getInglesII(){
		return Ingles_II;
	}
	
	public ArrayList<Arista> getMatematicasDiscretas(){
		return Matematicas_Discretas;
	}
	
	public ArrayList<Arista> getBiologiaParaIngenieros(){
		return Biologia_para_Ingenieros;
	}
	
	public ArrayList<Arista> getElectricidadyElectronica(){
		return Electricidad_y_Electronica;
	}
	
	public ArrayList<Arista> getAutomatasyLenguajesFormales(){
		return Automatas_y_Lenguajes_Formales;
	}
	
	public ArrayList<Arista> getBasedeDatosI(){
		return Base_de_Datos_I;
	}
	
	public ArrayList<Arista> getBasedeDatosII(){
		return Base_de_Datos_II;
	}
	
	public ArrayList<Arista> getSistemasDigitales(){
		return Sistemas_Digitales;
	}
	
	public ArrayList<Arista> getAnalisisNumericoI(){
		return Analisis_Numerico_I;
	}
	
	public ArrayList<Arista> getPensamientoSistemicoyOrganizacional(){
		return Pensamiento_Sistemico_y_Organizacional;
	}
	
	public ArrayList<Arista> getDireccionEmpresarialI(){
		return Direccion_Empresarial_I;
	}
	
	public ArrayList<Arista> getEstadisticaI(){
		return Estadistica_I;
	}
	
	public ArrayList<Arista> getRedesDeComputadoresI(){
		return Redes_de_Computadores_I;
	}
	
	public ArrayList<Arista> getArquitecturaDeComputadores(){
		return Arquitectura_de_Computadores;
	}
	
	public ArrayList<Arista> getProgramacionenlaWeb(){
		return Programacion_en_la_Web;
	}
	
	public ArrayList<Arista> getSistemasDeInformacion(){
	 return Sistemas_de_Informacion;
	}
	
	public ArrayList<Arista> getEstadistica_II() {
	    return Estadistica_II;
	}

	public ArrayList<Arista> getIngenieriadelSoftwareI() {
	    return Ingenieria_del_Software_I;
	}

	public ArrayList<Arista> getRedesdeComputadoresII() {
	    return Redes_de_Computadores_II;
	}

	public ArrayList<Arista> getInteligenciaArtificialI() {
	    return Inteligencia_Artificial_I;
	}

	public ArrayList<Arista> getSistemasOperacionales() {
	    return Sistemas_Operacionales;
	}

	public ArrayList<Arista> getIngenieriadelSoftware_II() {
	    return Ingenieria_del_Software_II;
	}

	public ArrayList<Arista> getSimulacionDigital() {
	    return Simulacion_Digital;
	}

	public ArrayList<Arista> getIngenieriaEconomica() {
	    return Ingenieria_Economica;
	}

	public ArrayList<Arista> getTrabajodeGradoI() {
	    return Trabajo_de_Grado_I;
	}

	public ArrayList<Arista> getEconomiaEmpresarial() {
	    return Economia_Empresarial;
	}

	public ArrayList<Arista> getTrabajodeGradoII() {
	    return Trabajo_de_Grado_II;
	}

	public void ImprimirArray(ArrayList<Arista> ArrayaImprimir) {
		StringBuilder impresion = new StringBuilder();
		for(int i = 0; i < ArrayaImprimir.size(); i++) {
			impresion.append(ArrayaImprimir.get(i).valor)
			.append("-->").append(ArrayaImprimir.get(i).nombre_profesor).append("\n");
			
			
		
		}
		JOptionPane.showMessageDialog(null, impresion.toString(),"Informacion Votos",JOptionPane.INFORMATION_MESSAGE);
		
	}
}


//- Santiago ArrayLIST
//- Nixon Jframe Votaciones
//- Camilo Grafo Graficamente.
//- Diego Creando el codigo para buscar el camino mas pesado *Tiene que ser para un grafo dirigido*.